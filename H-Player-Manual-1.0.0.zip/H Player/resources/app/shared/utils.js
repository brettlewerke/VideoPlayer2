"use strict";
/**
 * Utility functions for file path parsing, media detection, and string manipulation
 */
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.isVideoFile = isVideoFile;
exports.isSubtitleFile = isSubtitleFile;
exports.isImageFile = isImageFile;
exports.shouldIgnore = shouldIgnore;
exports.parseMovieTitle = parseMovieTitle;
exports.parseEpisodeInfo = parseEpisodeInfo;
exports.parseSeasonNumber = parseSeasonNumber;
exports.isMoviesFolder = isMoviesFolder;
exports.isTVShowsFolder = isTVShowsFolder;
exports.normalizePath = normalizePath;
exports.generateMediaId = generateMediaId;
exports.hashString = hashString;
exports.findPrimaryVideoFile = findPrimaryVideoFile;
exports.findSubtitleFiles = findSubtitleFiles;
exports.findArtworkFiles = findArtworkFiles;
exports.sanitizeFilename = sanitizeFilename;
exports.formatDuration = formatDuration;
exports.formatFileSize = formatFileSize;
exports.debounce = debounce;
const path_1 = __importDefault(require("path"));
const constants_js_1 = require("./constants.js");
/**
 * Check if a file has a video extension
 */
function isVideoFile(filename) {
    const ext = path_1.default.extname(filename).toLowerCase();
    return constants_js_1.VIDEO_EXTENSIONS.includes(ext);
}
/**
 * Check if a file has a subtitle extension
 */
function isSubtitleFile(filename) {
    const ext = path_1.default.extname(filename).toLowerCase();
    return constants_js_1.SUBTITLE_EXTENSIONS.includes(ext);
}
/**
 * Check if a file has an image extension
 */
function isImageFile(filename) {
    const ext = path_1.default.extname(filename).toLowerCase();
    return constants_js_1.IMAGE_EXTENSIONS.includes(ext);
}
/**
 * Check if a file or folder should be ignored during scanning
 */
function shouldIgnore(name, includesSamples = false, includesTrailers = false) {
    const lowerName = name.toLowerCase();
    for (const pattern of constants_js_1.IGNORE_PATTERNS) {
        if (pattern.test(lowerName)) {
            // Allow samples/trailers if explicitly enabled
            if (!includesSamples && (lowerName.includes('sample') || lowerName.includes('samples'))) {
                return true;
            }
            if (!includesTrailers && (lowerName.includes('trailer') || lowerName.includes('trailers'))) {
                return true;
            }
            return true;
        }
    }
    return false;
}
/**
 * Parse movie title and year from folder name
 */
function parseMovieTitle(folderName) {
    const yearMatch = folderName.match(/\((\d{4})\)$/);
    if (yearMatch) {
        const title = folderName.replace(/\s*\(\d{4}\)$/, '').trim();
        const year = parseInt(yearMatch[1], 10);
        return { title, year };
    }
    return { title: folderName.trim() };
}
function parseEpisodeInfo(filename, defaultSeason = 1) {
    const baseName = path_1.default.basename(filename, path_1.default.extname(filename));
    for (const pattern of constants_js_1.EPISODE_PATTERNS) {
        const match = baseName.match(pattern);
        if (match) {
            if (pattern === constants_js_1.EPISODE_PATTERNS[0] || pattern === constants_js_1.EPISODE_PATTERNS[1]) {
                // S01E01 or 1x01 format
                const seasonNumber = parseInt(match[1], 10);
                const episodeNumber = parseInt(match[2], 10);
                return { seasonNumber, episodeNumber };
            }
            else if (pattern === constants_js_1.EPISODE_PATTERNS[2]) {
                // 101 format (season + episode)
                const seasonNumber = parseInt(match[1], 10);
                const episodeNumber = parseInt(match[2], 10);
                return { seasonNumber, episodeNumber };
            }
            else if (pattern === constants_js_1.EPISODE_PATTERNS[3]) {
                // Episode 1 format
                const episodeNumber = parseInt(match[1], 10);
                return { seasonNumber: defaultSeason, episodeNumber };
            }
            else if (pattern === constants_js_1.EPISODE_PATTERNS[4]) {
                // Multi-episode format S01E01E02
                const seasonNumber = parseInt(match[1], 10);
                const episodeNumber = parseInt(match[2], 10);
                const additionalEpisodes = match[3] ? [parseInt(match[3], 10)] : undefined;
                return { seasonNumber, episodeNumber, additionalEpisodes };
            }
        }
    }
    return null;
}
/**
 * Parse season number from folder name
 */
function parseSeasonNumber(folderName) {
    const match = folderName.match(constants_js_1.FOLDER_NAMES.SEASON);
    if (match) {
        return parseInt(match[1], 10);
    }
    // Check for "Specials" folder (season 0)
    if (constants_js_1.FOLDER_NAMES.SPECIALS.some(name => folderName.toLowerCase() === name.toLowerCase())) {
        return 0;
    }
    return null;
}
/**
 * Check if folder name indicates it contains movies
 */
function isMoviesFolder(folderName) {
    const lowerName = folderName.toLowerCase();
    return constants_js_1.FOLDER_NAMES.MOVIES.some(name => lowerName === name);
}
/**
 * Check if folder name indicates it contains TV shows
 */
function isTVShowsFolder(folderName) {
    const lowerName = folderName.toLowerCase();
    return constants_js_1.FOLDER_NAMES.TV_SHOWS.some(name => lowerName === name);
}
/**
 * Normalize path for cross-platform compatibility
 */
function normalizePath(filePath) {
    return path_1.default.normalize(filePath).replace(/\\/g, '/');
}
/**
 * Generate a stable ID for media items based on path, size, and timestamp
 */
function generateMediaId(volumeId, filePath, size, lastModified) {
    const normalizedPath = normalizePath(filePath);
    const components = [volumeId, normalizedPath, size.toString(), lastModified.toString()];
    return hashString(components.join('|'));
}
/**
 * Simple hash function for generating IDs
 */
function hashString(str) {
    let hash = 0;
    for (let i = 0; i < str.length; i++) {
        const char = str.charCodeAt(i);
        hash = ((hash << 5) - hash) + char;
        hash = hash & hash; // Convert to 32-bit integer
    }
    return Math.abs(hash).toString(36);
}
/**
 * Find the largest video file in a directory (for movies)
 */
function findPrimaryVideoFile(files) {
    const videoFiles = files.filter(isVideoFile);
    if (videoFiles.length === 0) {
        return null;
    }
    if (videoFiles.length === 1) {
        return videoFiles[0];
    }
    // In a real implementation, we would check file sizes
    // For now, just return the first one alphabetically
    return videoFiles.sort()[0];
}
/**
 * Find subtitle files for a video file
 */
function findSubtitleFiles(videoPath, allFiles) {
    const videoBaseName = path_1.default.basename(videoPath, path_1.default.extname(videoPath));
    const videoDir = path_1.default.dirname(videoPath);
    return allFiles.filter(file => {
        if (!isSubtitleFile(file)) {
            return false;
        }
        const fileDir = path_1.default.dirname(file);
        if (fileDir !== videoDir) {
            return false;
        }
        const fileBaseName = path_1.default.basename(file, path_1.default.extname(file));
        return fileBaseName.startsWith(videoBaseName);
    });
}
/**
 * Find artwork files in a directory
 */
function findArtworkFiles(directory, allFiles) {
    const result = {};
    const filesInDir = allFiles.filter(file => path_1.default.dirname(file) === directory && isImageFile(file));
    // Look for poster
    for (const posterName of constants_js_1.ARTWORK_FILENAMES.POSTER) {
        const found = filesInDir.find(file => path_1.default.basename(file).toLowerCase() === posterName.toLowerCase());
        if (found) {
            result.poster = found;
            break;
        }
    }
    // Look for backdrop
    for (const backdropName of constants_js_1.ARTWORK_FILENAMES.BACKDROP) {
        const found = filesInDir.find(file => path_1.default.basename(file).toLowerCase() === backdropName.toLowerCase());
        if (found) {
            result.backdrop = found;
            break;
        }
    }
    return result;
}
/**
 * Sanitize filename for safe storage
 */
function sanitizeFilename(filename) {
    return filename
        .replace(/[<>:"/\\|?*]/g, '_')
        .replace(/\s+/g, ' ')
        .trim();
}
/**
 * Format duration in seconds to human readable string
 */
function formatDuration(seconds) {
    const hours = Math.floor(seconds / 3600);
    const minutes = Math.floor((seconds % 3600) / 60);
    const secs = Math.floor(seconds % 60);
    if (hours > 0) {
        return `${hours}:${minutes.toString().padStart(2, '0')}:${secs.toString().padStart(2, '0')}`;
    }
    else {
        return `${minutes}:${secs.toString().padStart(2, '0')}`;
    }
}
/**
 * Format file size in bytes to human readable string
 */
function formatFileSize(bytes) {
    const units = ['B', 'KB', 'MB', 'GB', 'TB'];
    let size = bytes;
    let unitIndex = 0;
    while (size >= 1024 && unitIndex < units.length - 1) {
        size /= 1024;
        unitIndex++;
    }
    return `${size.toFixed(unitIndex === 0 ? 0 : 1)} ${units[unitIndex]}`;
}
/**
 * Debounce function for limiting rapid function calls
 */
function debounce(func, delay) {
    let timeoutId;
    return (...args) => {
        clearTimeout(timeoutId);
        timeoutId = setTimeout(() => func(...args), delay);
    };
}
