"use strict";
/**
 * Player interface that abstracts the underlying media player backend
 * This allows swapping between mpv, libVLC, or other backends
 */
Object.defineProperty(exports, "__esModule", { value: true });
