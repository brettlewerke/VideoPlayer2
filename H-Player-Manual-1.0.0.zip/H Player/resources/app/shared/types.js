"use strict";
/**
 * Shared types and interfaces used across main and renderer processes
 */
Object.defineProperty(exports, "__esModule", { value: true });
exports.MediaPlayerError = void 0;
// Error types
class MediaPlayerError extends Error {
    constructor(message, code, details) {
        super(message);
        this.code = code;
        this.details = details;
        this.name = 'MediaPlayerError';
    }
}
exports.MediaPlayerError = MediaPlayerError;
