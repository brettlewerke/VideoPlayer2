"use strict";
/**
 * Media scanner for discovering and indexing video files
 */
Object.defineProperty(exports, "__esModule", { value: true });
exports.MediaScanner = void 0;
const events_1 = require("events");
const fs_1 = require("fs");
const path_1 = require("path");
const utils_js_1 = require("../../shared/utils.js");
class MediaScanner extends events_1.EventEmitter {
    constructor(database) {
        super();
        this.database = database;
        this.isScanning = false;
        this.currentScanProgress = null;
    }
    async initialize() {
        console.log('Media scanner initialized successfully');
    }
    async scanAllDrives() {
        if (this.isScanning) {
            console.warn('Scan already in progress');
            return;
        }
        try {
            const drives = await this.database.getDrives();
            const connectedDrives = drives.filter(drive => drive.isConnected);
            console.log(`Starting scan of ${connectedDrives.length} connected drives`);
            for (const drive of connectedDrives) {
                await this.scanDrive(drive);
            }
            console.log('Scan of all drives completed');
        }
        catch (error) {
            console.error('Failed to scan drives:', error);
            throw error;
        }
    }
    async scanDrive(drive) {
        if (this.isScanning) {
            throw new Error('Scanner is already running');
        }
        this.isScanning = true;
        try {
            console.log(`Scanning drive: ${drive.label} (${drive.mountPath})`);
            const result = await this.performScan(drive);
            // Update drive's last scanned timestamp
            await this.database.insertDrive({
                ...drive,
                lastScanned: new Date(),
            });
            console.log(`Scan completed for drive ${drive.label}:`, {
                movies: result.movies.length,
                shows: result.shows.length,
                seasons: result.seasons.length,
                episodes: result.episodes.length,
                errors: result.errors.length,
            });
            return result;
        }
        finally {
            this.isScanning = false;
            this.currentScanProgress = null;
        }
    }
    async scanPath(path) {
        if (!(0, fs_1.existsSync)(path)) {
            throw new Error(`Path does not exist: ${path}`);
        }
        console.log(`Scanning path: ${path}`);
        // Create a temporary drive entry for this path
        const tempDrive = {
            id: (0, utils_js_1.generateMediaId)('temp', path, 0, Date.now()),
            label: (0, path_1.basename)(path),
            mountPath: path,
            isRemovable: false,
            isConnected: true,
            createdAt: new Date(),
            updatedAt: new Date(),
        };
        await this.scanDrive(tempDrive);
    }
    async performScan(drive) {
        const result = {
            movies: [],
            shows: [],
            seasons: [],
            episodes: [],
            errors: [],
        };
        try {
            const allFiles = this.getAllFiles(drive.mountPath);
            this.currentScanProgress = {
                driveId: drive.id,
                driveName: drive.label,
                totalFiles: allFiles.length,
                processedFiles: 0,
                isComplete: false,
            };
            // Look for Movies and TV Shows folders
            const rootEntries = this.getDirectoryEntries(drive.mountPath);
            for (const entry of rootEntries) {
                const entryPath = (0, path_1.join)(drive.mountPath, entry);
                if (!this.isDirectory(entryPath)) {
                    continue;
                }
                if ((0, utils_js_1.isMoviesFolder)(entry)) {
                    console.log(`Found Movies folder: ${entryPath}`);
                    const movies = await this.scanMoviesFolder(entryPath, drive, allFiles);
                    result.movies.push(...movies);
                }
                else if ((0, utils_js_1.isTVShowsFolder)(entry)) {
                    console.log(`Found TV Shows folder: ${entryPath}`);
                    const scanResult = await this.scanTVShowsFolder(entryPath, drive, allFiles);
                    result.shows.push(...scanResult.shows);
                    result.seasons.push(...scanResult.seasons);
                    result.episodes.push(...scanResult.episodes);
                }
            }
            // Save results to database
            await this.saveResults(result);
            this.currentScanProgress.isComplete = true;
            this.emit('scanProgress', this.currentScanProgress);
        }
        catch (error) {
            result.errors.push(error instanceof Error ? error.message : 'Unknown error');
            console.error('Scan error:', error);
        }
        return result;
    }
    async scanMoviesFolder(moviesPath, drive, allFiles) {
        const movies = [];
        try {
            const movieFolders = this.getDirectoryEntries(moviesPath);
            for (const folderName of movieFolders) {
                const folderPath = (0, path_1.join)(moviesPath, folderName);
                if (!this.isDirectory(folderPath) || (0, utils_js_1.shouldIgnore)(folderName)) {
                    continue;
                }
                try {
                    const movie = await this.scanMovieFolder(folderPath, folderName, drive, allFiles);
                    if (movie) {
                        movies.push(movie);
                    }
                }
                catch (error) {
                    console.error(`Error scanning movie folder ${folderName}:`, error);
                }
            }
        }
        catch (error) {
            console.error(`Error scanning movies folder ${moviesPath}:`, error);
        }
        return movies;
    }
    async scanMovieFolder(folderPath, folderName, drive, allFiles) {
        const filesInFolder = allFiles.filter(file => (0, path_1.dirname)(file) === folderPath);
        const videoFiles = filesInFolder.filter(utils_js_1.isVideoFile);
        if (videoFiles.length === 0) {
            return null;
        }
        // Find the primary video file (largest one)
        const primaryVideoPath = (0, utils_js_1.findPrimaryVideoFile)(videoFiles);
        if (!primaryVideoPath) {
            return null;
        }
        const { title, year } = (0, utils_js_1.parseMovieTitle)(folderName);
        const artwork = (0, utils_js_1.findArtworkFiles)(folderPath, allFiles);
        try {
            const stats = (0, fs_1.statSync)(primaryVideoPath);
            const videoFile = {
                id: (0, utils_js_1.generateMediaId)(drive.id, primaryVideoPath, stats.size, stats.mtimeMs),
                path: (0, utils_js_1.normalizePath)(primaryVideoPath),
                filename: (0, path_1.basename)(primaryVideoPath),
                size: stats.size,
                lastModified: stats.mtimeMs,
                extension: (0, path_1.extname)(primaryVideoPath),
            };
            const movie = {
                id: (0, utils_js_1.generateMediaId)(drive.id, folderPath, stats.size, stats.mtimeMs),
                title,
                year,
                path: (0, utils_js_1.normalizePath)(folderPath),
                driveId: drive.id,
                videoFile,
                posterPath: artwork.poster ? (0, utils_js_1.normalizePath)(artwork.poster) : undefined,
                backdropPath: artwork.backdrop ? (0, utils_js_1.normalizePath)(artwork.backdrop) : undefined,
                createdAt: new Date(),
                updatedAt: new Date(),
            };
            return movie;
        }
        catch (error) {
            console.error(`Error creating movie entry for ${folderName}:`, error);
            return null;
        }
    }
    async scanTVShowsFolder(tvShowsPath, drive, allFiles) {
        const shows = [];
        const seasons = [];
        const episodes = [];
        try {
            const showFolders = this.getDirectoryEntries(tvShowsPath);
            for (const showFolderName of showFolders) {
                const showFolderPath = (0, path_1.join)(tvShowsPath, showFolderName);
                if (!this.isDirectory(showFolderPath) || (0, utils_js_1.shouldIgnore)(showFolderName)) {
                    continue;
                }
                try {
                    const scanResult = await this.scanShowFolder(showFolderPath, showFolderName, drive, allFiles);
                    if (scanResult.show) {
                        shows.push(scanResult.show);
                        seasons.push(...scanResult.seasons);
                        episodes.push(...scanResult.episodes);
                    }
                }
                catch (error) {
                    console.error(`Error scanning show folder ${showFolderName}:`, error);
                }
            }
        }
        catch (error) {
            console.error(`Error scanning TV shows folder ${tvShowsPath}:`, error);
        }
        return { shows, seasons, episodes };
    }
    async scanShowFolder(showFolderPath, showFolderName, drive, allFiles) {
        const seasons = [];
        const episodes = [];
        const artwork = (0, utils_js_1.findArtworkFiles)(showFolderPath, allFiles);
        const show = {
            id: (0, utils_js_1.generateMediaId)(drive.id, showFolderPath, 0, Date.now()),
            title: showFolderName,
            path: (0, utils_js_1.normalizePath)(showFolderPath),
            driveId: drive.id,
            posterPath: artwork.poster ? (0, utils_js_1.normalizePath)(artwork.poster) : undefined,
            backdropPath: artwork.backdrop ? (0, utils_js_1.normalizePath)(artwork.backdrop) : undefined,
            createdAt: new Date(),
            updatedAt: new Date(),
        };
        // Look for season folders or loose episodes
        const entries = this.getDirectoryEntries(showFolderPath);
        const seasonFolders = [];
        const looseVideoFiles = [];
        for (const entry of entries) {
            const entryPath = (0, path_1.join)(showFolderPath, entry);
            if (this.isDirectory(entryPath)) {
                const seasonNumber = (0, utils_js_1.parseSeasonNumber)(entry);
                if (seasonNumber !== null) {
                    seasonFolders.push({
                        name: entry,
                        path: entryPath,
                        number: seasonNumber,
                    });
                }
            }
            else if ((0, utils_js_1.isVideoFile)(entry)) {
                looseVideoFiles.push(entryPath);
            }
        }
        // Process season folders
        for (const seasonFolder of seasonFolders) {
            const seasonResult = await this.scanSeasonFolder(seasonFolder.path, seasonFolder.name, seasonFolder.number, show, drive, allFiles);
            if (seasonResult.season) {
                seasons.push(seasonResult.season);
                episodes.push(...seasonResult.episodes);
            }
        }
        // Process loose video files as Season 1
        if (looseVideoFiles.length > 0) {
            const defaultSeasonPath = showFolderPath;
            const defaultSeason = {
                id: (0, utils_js_1.generateMediaId)(drive.id, defaultSeasonPath + '/season1', 0, Date.now()),
                showId: show.id,
                seasonNumber: 1,
                title: 'Season 1',
                path: (0, utils_js_1.normalizePath)(defaultSeasonPath),
                episodeCount: 0,
                createdAt: new Date(),
                updatedAt: new Date(),
            };
            const seasonEpisodes = await this.scanEpisodesInFolder(defaultSeasonPath, 1, defaultSeason, show, drive, allFiles);
            if (seasonEpisodes.length > 0) {
                defaultSeason.episodeCount = seasonEpisodes.length;
                seasons.push(defaultSeason);
                episodes.push(...seasonEpisodes);
            }
        }
        return { show, seasons, episodes };
    }
    async scanSeasonFolder(seasonPath, seasonName, seasonNumber, show, drive, allFiles) {
        const artwork = (0, utils_js_1.findArtworkFiles)(seasonPath, allFiles);
        const season = {
            id: (0, utils_js_1.generateMediaId)(drive.id, seasonPath, 0, Date.now()),
            showId: show.id,
            seasonNumber,
            title: seasonName,
            path: (0, utils_js_1.normalizePath)(seasonPath),
            posterPath: artwork.poster ? (0, utils_js_1.normalizePath)(artwork.poster) : undefined,
            episodeCount: 0,
            createdAt: new Date(),
            updatedAt: new Date(),
        };
        const episodes = await this.scanEpisodesInFolder(seasonPath, seasonNumber, season, show, drive, allFiles);
        season.episodeCount = episodes.length;
        return { season: episodes.length > 0 ? season : null, episodes };
    }
    async scanEpisodesInFolder(folderPath, seasonNumber, season, show, drive, allFiles) {
        const episodes = [];
        const filesInFolder = allFiles.filter(file => (0, path_1.dirname)(file) === folderPath);
        const videoFiles = filesInFolder.filter(utils_js_1.isVideoFile);
        for (const videoFile of videoFiles) {
            const filename = (0, path_1.basename)(videoFile);
            if ((0, utils_js_1.shouldIgnore)(filename)) {
                continue;
            }
            const episodeInfo = (0, utils_js_1.parseEpisodeInfo)(filename, seasonNumber);
            if (!episodeInfo) {
                continue;
            }
            try {
                const stats = (0, fs_1.statSync)(videoFile);
                const mediaFile = {
                    id: (0, utils_js_1.generateMediaId)(drive.id, videoFile, stats.size, stats.mtimeMs),
                    path: (0, utils_js_1.normalizePath)(videoFile),
                    filename,
                    size: stats.size,
                    lastModified: stats.mtimeMs,
                    extension: (0, path_1.extname)(videoFile),
                };
                const episode = {
                    id: (0, utils_js_1.generateMediaId)(drive.id, videoFile, stats.size, stats.mtimeMs),
                    showId: show.id,
                    seasonId: season.id,
                    episodeNumber: episodeInfo.episodeNumber,
                    seasonNumber: episodeInfo.seasonNumber,
                    title: episodeInfo.title,
                    path: (0, utils_js_1.normalizePath)(videoFile),
                    videoFile: mediaFile,
                    createdAt: new Date(),
                    updatedAt: new Date(),
                };
                episodes.push(episode);
                // Handle multi-episode files
                if (episodeInfo.additionalEpisodes) {
                    for (const additionalEpisodeNumber of episodeInfo.additionalEpisodes) {
                        const additionalEpisode = {
                            ...episode,
                            id: (0, utils_js_1.generateMediaId)(drive.id, videoFile + '_' + additionalEpisodeNumber, stats.size, stats.mtimeMs),
                            episodeNumber: additionalEpisodeNumber,
                        };
                        episodes.push(additionalEpisode);
                    }
                }
            }
            catch (error) {
                console.error(`Error processing episode file ${filename}:`, error);
            }
        }
        return episodes;
    }
    async saveResults(result) {
        try {
            // Use a transaction to ensure consistency
            await this.database.transaction(async () => {
                // Save movies
                for (const movie of result.movies) {
                    await this.database.insertMovie(movie);
                }
                // Save shows
                for (const show of result.shows) {
                    await this.database.insertShow(show);
                }
                // Save seasons
                for (const season of result.seasons) {
                    await this.database.insertSeason(season);
                }
                // Save episodes
                for (const episode of result.episodes) {
                    await this.database.insertEpisode(episode);
                }
            });
            console.log('Scan results saved to database successfully');
        }
        catch (error) {
            console.error('Failed to save scan results:', error);
            throw error;
        }
    }
    getAllFiles(rootPath) {
        const files = [];
        const scanDirectory = (dirPath) => {
            try {
                const entries = (0, fs_1.readdirSync)(dirPath);
                for (const entry of entries) {
                    if ((0, utils_js_1.shouldIgnore)(entry)) {
                        continue;
                    }
                    const fullPath = (0, path_1.join)(dirPath, entry);
                    try {
                        const stats = (0, fs_1.statSync)(fullPath);
                        if (stats.isDirectory()) {
                            scanDirectory(fullPath);
                        }
                        else if (stats.isFile()) {
                            files.push(fullPath);
                        }
                    }
                    catch (error) {
                        // Skip files we can't read
                        console.warn(`Cannot access ${fullPath}:`, error);
                    }
                }
            }
            catch (error) {
                console.warn(`Cannot read directory ${dirPath}:`, error);
            }
        };
        scanDirectory(rootPath);
        return files;
    }
    getDirectoryEntries(dirPath) {
        try {
            return (0, fs_1.readdirSync)(dirPath);
        }
        catch (error) {
            console.warn(`Cannot read directory ${dirPath}:`, error);
            return [];
        }
    }
    isDirectory(path) {
        try {
            return (0, fs_1.statSync)(path).isDirectory();
        }
        catch {
            return false;
        }
    }
    getScanningState() {
        return this.isScanning;
    }
    getCurrentProgress() {
        return this.currentScanProgress;
    }
}
exports.MediaScanner = MediaScanner;
