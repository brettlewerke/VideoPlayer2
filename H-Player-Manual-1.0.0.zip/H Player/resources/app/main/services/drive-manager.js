"use strict";
/**
 * Cross-platform drive detection and monitoring
 */
Object.defineProperty(exports, "__esModule", { value: true });
exports.DriveManager = void 0;
const events_1 = require("events");
const fs_1 = require("fs");
const path_1 = require("path");
const os_1 = require("os");
const child_process_1 = require("child_process");
const utils_js_1 = require("../../shared/utils.js");
class DriveManager extends events_1.EventEmitter {
    constructor(database) {
        super();
        this.database = database;
        this.watchers = [];
        this.detectedDrives = new Map();
        this.isMonitoring = false;
        this.platform = (0, os_1.platform)();
    }
    async initialize() {
        try {
            await this.scanForDrives();
            console.log('Drive manager initialized successfully');
        }
        catch (error) {
            console.error('Failed to initialize drive manager:', error);
            throw error;
        }
    }
    startMonitoring() {
        if (this.isMonitoring) {
            return;
        }
        this.isMonitoring = true;
        try {
            if (this.platform === 'win32') {
                this.startWindowsMonitoring();
            }
            else if (this.platform === 'darwin') {
                this.startMacOSMonitoring();
            }
            else {
                this.startLinuxMonitoring();
            }
            console.log('Drive monitoring started');
        }
        catch (error) {
            console.error('Failed to start drive monitoring:', error);
            this.isMonitoring = false;
        }
    }
    stopMonitoring() {
        if (!this.isMonitoring) {
            return;
        }
        this.watchers.forEach(watcher => {
            try {
                watcher.close();
            }
            catch (error) {
                console.error('Error closing file watcher:', error);
            }
        });
        this.watchers = [];
        this.isMonitoring = false;
        console.log('Drive monitoring stopped');
    }
    async scanForDrives() {
        const drives = [];
        try {
            if (this.platform === 'win32') {
                drives.push(...await this.scanWindowsDrives());
            }
            else if (this.platform === 'darwin') {
                drives.push(...await this.scanMacOSDrives());
            }
            else {
                drives.push(...await this.scanLinuxDrives());
            }
            // Update database with discovered drives
            for (const drive of drives) {
                const existingDrive = this.detectedDrives.get(drive.id);
                if (!existingDrive || existingDrive.isConnected !== drive.isConnected) {
                    await this.database.insertDrive(drive);
                    this.detectedDrives.set(drive.id, drive);
                    if (drive.isConnected) {
                        this.emit('driveConnected', drive);
                    }
                    else {
                        this.emit('driveDisconnected', drive);
                    }
                }
            }
            // Mark drives as disconnected if they're no longer detected
            for (const [driveId, existingDrive] of this.detectedDrives) {
                const stillExists = drives.some(d => d.id === driveId);
                if (!stillExists && existingDrive.isConnected) {
                    existingDrive.isConnected = false;
                    await this.database.updateDriveConnection(driveId, false);
                    this.emit('driveDisconnected', existingDrive);
                }
            }
            console.log(`Detected ${drives.length} drives`);
        }
        catch (error) {
            console.error('Failed to scan for drives:', error);
        }
    }
    async scanWindowsDrives() {
        const drives = [];
        try {
            // Get all drive letters
            const output = (0, child_process_1.execSync)('wmic logicaldisk get size,freespace,caption,description,drivetype', { encoding: 'utf8' });
            const lines = output.split('\\n').filter(line => line.trim() && !line.includes('Caption'));
            for (const line of lines) {
                const parts = line.trim().split(/\\s+/);
                if (parts.length >= 5) {
                    const caption = parts[0]; // C:
                    const driveType = parseInt(parts[2]); // 2=removable, 3=fixed, etc.
                    if (caption && caption.match(/^[A-Z]:$/)) {
                        const mountPath = caption + '\\\\';
                        if ((0, fs_1.existsSync)(mountPath)) {
                            const drive = {
                                id: (0, utils_js_1.hashString)(`win32:${caption}`),
                                label: this.getDriveLabel(mountPath) || caption,
                                mountPath,
                                isRemovable: driveType === 2,
                                isConnected: true,
                                createdAt: new Date(),
                                updatedAt: new Date(),
                            };
                            drives.push(drive);
                        }
                    }
                }
            }
        }
        catch (error) {
            console.error('Error scanning Windows drives:', error);
            // Fallback: try common drive letters
            for (const letter of 'CDEFGHIJKLMNOPQRSTUVWXYZ') {
                const mountPath = `${letter}:\\\\`;
                if ((0, fs_1.existsSync)(mountPath)) {
                    drives.push({
                        id: (0, utils_js_1.hashString)(`win32:${letter}:`),
                        label: this.getDriveLabel(mountPath) || `${letter}:`,
                        mountPath,
                        isRemovable: false, // Can't determine, assume fixed
                        isConnected: true,
                        createdAt: new Date(),
                        updatedAt: new Date(),
                    });
                }
            }
        }
        return drives;
    }
    async scanMacOSDrives() {
        const drives = [];
        const volumesPath = '/Volumes';
        if ((0, fs_1.existsSync)(volumesPath)) {
            try {
                const entries = (0, fs_1.readdirSync)(volumesPath);
                for (const entry of entries) {
                    const mountPath = (0, path_1.join)(volumesPath, entry);
                    try {
                        const stats = (0, fs_1.statSync)(mountPath);
                        if (stats.isDirectory()) {
                            const drive = {
                                id: (0, utils_js_1.hashString)(`darwin:${entry}`),
                                label: entry,
                                mountPath,
                                isRemovable: this.isMacOSRemovableDrive(mountPath),
                                isConnected: true,
                                createdAt: new Date(),
                                updatedAt: new Date(),
                            };
                            drives.push(drive);
                        }
                    }
                    catch (error) {
                        console.warn(`Error checking volume ${entry}:`, error);
                    }
                }
            }
            catch (error) {
                console.error('Error reading /Volumes:', error);
            }
        }
        // Also include root filesystem
        drives.push({
            id: (0, utils_js_1.hashString)('darwin:root'),
            label: 'Root Filesystem',
            mountPath: '/',
            isRemovable: false,
            isConnected: true,
            createdAt: new Date(),
            updatedAt: new Date(),
        });
        return drives;
    }
    async scanLinuxDrives() {
        const drives = [];
        const mediaPaths = ['/media', '/run/media'];
        // Add user-specific media paths
        if (process.env.USER) {
            mediaPaths.push(`/media/${process.env.USER}`, `/run/media/${process.env.USER}`);
        }
        for (const mediaPath of mediaPaths) {
            if ((0, fs_1.existsSync)(mediaPath)) {
                try {
                    const entries = (0, fs_1.readdirSync)(mediaPath);
                    for (const entry of entries) {
                        const mountPath = (0, path_1.join)(mediaPath, entry);
                        try {
                            const stats = (0, fs_1.statSync)(mountPath);
                            if (stats.isDirectory()) {
                                const drive = {
                                    id: (0, utils_js_1.hashString)(`linux:${mountPath}`),
                                    label: entry,
                                    mountPath,
                                    isRemovable: true, // Media mounts are typically removable
                                    isConnected: true,
                                    createdAt: new Date(),
                                    updatedAt: new Date(),
                                };
                                drives.push(drive);
                            }
                        }
                        catch (error) {
                            console.warn(`Error checking mount ${entry}:`, error);
                        }
                    }
                }
                catch (error) {
                    console.warn(`Error reading ${mediaPath}:`, error);
                }
            }
        }
        // Also include root filesystem
        drives.push({
            id: (0, utils_js_1.hashString)('linux:root'),
            label: 'Root Filesystem',
            mountPath: '/',
            isRemovable: false,
            isConnected: true,
            createdAt: new Date(),
            updatedAt: new Date(),
        });
        return drives;
    }
    getDriveLabel(mountPath) {
        if (this.platform === 'win32') {
            try {
                const output = (0, child_process_1.execSync)(`vol ${mountPath.replace('\\\\', '')}`, { encoding: 'utf8' });
                const match = output.match(/Volume in drive [A-Z] is (.+)/);
                return match ? match[1].trim() : null;
            }
            catch {
                return null;
            }
        }
        return null;
    }
    isMacOSRemovableDrive(mountPath) {
        try {
            const output = (0, child_process_1.execSync)(`diskutil info "${mountPath}"`, { encoding: 'utf8' });
            return output.includes('Removable Media: Yes') || output.includes('Protocol: USB');
        }
        catch {
            return false;
        }
    }
    startWindowsMonitoring() {
        // On Windows, we poll for drive changes since monitoring drive letters is complex
        const pollInterval = setInterval(async () => {
            await this.scanForDrives();
        }, 5000); // Poll every 5 seconds
        // Store the interval ID in a way that can be cleared
        const watcher = {
            close: () => clearInterval(pollInterval)
        };
        this.watchers.push(watcher);
    }
    startMacOSMonitoring() {
        try {
            const watcher = (0, fs_1.watch)('/Volumes', { persistent: false }, async (eventType, filename) => {
                if (filename) {
                    console.log(`Volume change detected: ${eventType} ${filename}`);
                    // Debounce rapid changes
                    setTimeout(async () => {
                        await this.scanForDrives();
                    }, 1000);
                }
            });
            this.watchers.push(watcher);
        }
        catch (error) {
            console.error('Failed to watch /Volumes:', error);
            this.startPollingFallback();
        }
    }
    startLinuxMonitoring() {
        const mediaPaths = ['/media', '/run/media'];
        for (const mediaPath of mediaPaths) {
            if ((0, fs_1.existsSync)(mediaPath)) {
                try {
                    const watcher = (0, fs_1.watch)(mediaPath, { persistent: false, recursive: true }, async (eventType, filename) => {
                        if (filename) {
                            console.log(`Media change detected: ${eventType} ${filename}`);
                            // Debounce rapid changes
                            setTimeout(async () => {
                                await this.scanForDrives();
                            }, 1000);
                        }
                    });
                    this.watchers.push(watcher);
                }
                catch (error) {
                    console.warn(`Failed to watch ${mediaPath}:`, error);
                }
            }
        }
        // Fallback to polling if no watchers were set up
        if (this.watchers.length === 0) {
            this.startPollingFallback();
        }
    }
    startPollingFallback() {
        const pollInterval = setInterval(async () => {
            await this.scanForDrives();
        }, 10000); // Poll every 10 seconds
        const watcher = {
            close: () => clearInterval(pollInterval)
        };
        this.watchers.push(watcher);
    }
    getDrives() {
        return Array.from(this.detectedDrives.values());
    }
    getDrive(driveId) {
        return this.detectedDrives.get(driveId);
    }
}
exports.DriveManager = DriveManager;
