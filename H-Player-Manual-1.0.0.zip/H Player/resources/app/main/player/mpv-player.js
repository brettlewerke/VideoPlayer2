"use strict";
/**
 * MPV player backend implementation
 */
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.MpvPlayer = void 0;
const events_1 = require("events");
const child_process_1 = require("child_process");
const fs_1 = require("fs");
const path_1 = require("path");
const os_1 = require("os");
const net_1 = __importDefault(require("net"));
class MpvPlayer extends events_1.EventEmitter {
    constructor(config) {
        super();
        this.config = config;
        this.process = null;
        this.socket = null;
        this.isReady = false;
        this.requestId = 0;
        this.pendingRequests = new Map();
        this.socketPath = (0, path_1.join)((0, os_1.tmpdir)(), `mpv-socket-${Date.now()}-${Math.random().toString(36).substr(2, 9)}`);
        this.currentStatus = {
            state: 'idle',
            position: 0,
            duration: 0,
            volume: 1.0,
            isMuted: false,
            tracks: { audio: [], subtitles: [] },
        };
    }
    async loadMedia(request) {
        try {
            await this.ensureStarted();
            const command = {
                command: ['loadfile', request.path],
            };
            await this.sendCommand(command);
            if (request.resumePosition && request.resumePosition > 0) {
                // Wait a moment for the file to load, then seek
                setTimeout(async () => {
                    await this.seek(request.resumePosition);
                }, 100);
            }
            this.currentStatus.state = 'loading';
            this.emit('statusChanged', this.currentStatus);
        }
        catch (error) {
            this.emit('error', new Error(`Failed to load media: ${error}`));
        }
    }
    async play() {
        try {
            await this.ensureStarted();
            await this.sendCommand({ command: ['set_property', 'pause', false] });
        }
        catch (error) {
            this.emit('error', new Error(`Failed to play: ${error}`));
        }
    }
    async pause() {
        try {
            await this.ensureStarted();
            await this.sendCommand({ command: ['set_property', 'pause', true] });
        }
        catch (error) {
            this.emit('error', new Error(`Failed to pause: ${error}`));
        }
    }
    async stop() {
        try {
            await this.ensureStarted();
            await this.sendCommand({ command: ['stop'] });
        }
        catch (error) {
            this.emit('error', new Error(`Failed to stop: ${error}`));
        }
    }
    async seek(position) {
        try {
            await this.ensureStarted();
            await this.sendCommand({ command: ['seek', position, 'absolute'] });
        }
        catch (error) {
            this.emit('error', new Error(`Failed to seek: ${error}`));
        }
    }
    async setVolume(volume) {
        try {
            await this.ensureStarted();
            const volumePercent = Math.max(0, Math.min(100, volume * 100));
            await this.sendCommand({ command: ['set_property', 'volume', volumePercent] });
        }
        catch (error) {
            this.emit('error', new Error(`Failed to set volume: ${error}`));
        }
    }
    async setMuted(muted) {
        try {
            await this.ensureStarted();
            await this.sendCommand({ command: ['set_property', 'mute', muted] });
        }
        catch (error) {
            this.emit('error', new Error(`Failed to set muted: ${error}`));
        }
    }
    async setAudioTrack(trackId) {
        try {
            await this.ensureStarted();
            await this.sendCommand({ command: ['set_property', 'aid', trackId] });
        }
        catch (error) {
            this.emit('error', new Error(`Failed to set audio track: ${error}`));
        }
    }
    async setSubtitleTrack(trackId) {
        try {
            await this.ensureStarted();
            const sid = trackId === -1 ? false : trackId;
            await this.sendCommand({ command: ['set_property', 'sid', sid] });
        }
        catch (error) {
            this.emit('error', new Error(`Failed to set subtitle track: ${error}`));
        }
    }
    getStatus() {
        return { ...this.currentStatus };
    }
    getTracks() {
        return { ...this.currentStatus.tracks };
    }
    async destroy() {
        try {
            if (this.socket) {
                this.socket.destroy();
                this.socket = null;
            }
            if (this.process) {
                this.process.kill('SIGTERM');
                this.process = null;
            }
            // Clean up socket file
            if ((0, fs_1.existsSync)(this.socketPath)) {
                try {
                    (0, fs_1.unlinkSync)(this.socketPath);
                }
                catch {
                    // Ignore cleanup errors
                }
            }
            this.isReady = false;
            this.pendingRequests.clear();
        }
        catch (error) {
            console.error('Error destroying MPV player:', error);
        }
    }
    isAvailable() {
        return (0, fs_1.existsSync)(this.config.executablePath || 'mpv');
    }
    async ensureStarted() {
        if (this.isReady) {
            return;
        }
        await this.startMpv();
        await this.connectSocket();
        await this.setupEventListeners();
        this.isReady = true;
    }
    async startMpv() {
        return new Promise((resolve, reject) => {
            const executable = this.config.executablePath || 'mpv';
            const args = [
                '--no-video', // We'll enable video when needed
                '--idle=yes',
                '--no-terminal',
                '--no-config',
                '--load-scripts=no',
                '--audio-display=no',
                '--force-window=no',
                `--input-ipc-server=${this.socketPath}`,
                '--msg-level=all=v',
                ...(this.config.args || []),
            ];
            console.log(`Starting MPV: ${executable} ${args.join(' ')}`);
            this.process = (0, child_process_1.spawn)(executable, args, {
                stdio: ['ignore', 'pipe', 'pipe'],
                detached: false,
            });
            this.process.on('error', (error) => {
                reject(new Error(`Failed to start MPV: ${error.message}`));
            });
            this.process.on('exit', (code, signal) => {
                console.log(`MPV process exited with code ${code}, signal ${signal}`);
                this.isReady = false;
                this.emit('error', new Error(`MPV process exited unexpectedly`));
            });
            // Give MPV a moment to start and create the socket
            setTimeout(() => {
                if (this.process && !this.process.killed) {
                    resolve();
                }
                else {
                    reject(new Error('MPV failed to start'));
                }
            }, 1000);
        });
    }
    async connectSocket() {
        return new Promise((resolve, reject) => {
            let attempts = 0;
            const maxAttempts = 10;
            const tryConnect = () => {
                attempts++;
                this.socket = net_1.default.createConnection(this.socketPath);
                this.socket.on('connect', () => {
                    console.log('Connected to MPV socket');
                    resolve();
                });
                this.socket.on('error', (error) => {
                    if (attempts < maxAttempts) {
                        console.log(`Socket connection attempt ${attempts} failed, retrying...`);
                        setTimeout(tryConnect, 200);
                    }
                    else {
                        reject(new Error(`Failed to connect to MPV socket after ${maxAttempts} attempts: ${error.message}`));
                    }
                });
                this.socket.on('data', (data) => {
                    this.handleSocketData(data);
                });
                this.socket.on('close', () => {
                    console.log('MPV socket closed');
                    this.socket = null;
                });
            };
            tryConnect();
        });
    }
    async setupEventListeners() {
        // Observe key properties for status updates
        const observeCommands = [
            { command: ['observe_property', 1, 'pause'] },
            { command: ['observe_property', 2, 'time-pos'] },
            { command: ['observe_property', 3, 'duration'] },
            { command: ['observe_property', 4, 'volume'] },
            { command: ['observe_property', 5, 'mute'] },
            { command: ['observe_property', 6, 'track-list'] },
        ];
        for (const cmd of observeCommands) {
            await this.sendCommand(cmd);
        }
    }
    handleSocketData(data) {
        const lines = data.toString().trim().split('\n');
        for (const line of lines) {
            if (!line.trim())
                continue;
            try {
                const message = JSON.parse(line);
                this.handleMessage(message);
            }
            catch (error) {
                console.error('Failed to parse MPV message:', error, line);
            }
        }
    }
    handleMessage(message) {
        if (message.request_id && this.pendingRequests.has(message.request_id)) {
            const resolver = this.pendingRequests.get(message.request_id);
            this.pendingRequests.delete(message.request_id);
            resolver(message);
            return;
        }
        if (message.event) {
            this.handleEvent(message);
        }
    }
    handleEvent(event) {
        switch (event.event) {
            case 'property-change':
                this.handlePropertyChange(event);
                break;
            case 'playback-restart':
                this.currentStatus.state = 'playing';
                this.emit('statusChanged', this.currentStatus);
                break;
            case 'end-file':
                this.currentStatus.state = 'idle';
                this.currentStatus.position = 0;
                this.emit('statusChanged', this.currentStatus);
                this.emit('ended');
                break;
            case 'file-loaded':
                this.updateTracks();
                break;
        }
    }
    handlePropertyChange(event) {
        const { name, data } = event;
        let statusChanged = false;
        switch (name) {
            case 'pause':
                const newState = data ? 'paused' : 'playing';
                if (this.currentStatus.state !== newState) {
                    this.currentStatus.state = newState;
                    statusChanged = true;
                }
                break;
            case 'time-pos':
                if (typeof data === 'number' && data !== this.currentStatus.position) {
                    this.currentStatus.position = data;
                    statusChanged = true;
                }
                break;
            case 'duration':
                if (typeof data === 'number' && data !== this.currentStatus.duration) {
                    this.currentStatus.duration = data;
                    statusChanged = true;
                }
                break;
            case 'volume':
                if (typeof data === 'number') {
                    const volume = data / 100;
                    if (volume !== this.currentStatus.volume) {
                        this.currentStatus.volume = volume;
                        statusChanged = true;
                    }
                }
                break;
            case 'mute':
                if (typeof data === 'boolean' && data !== this.currentStatus.isMuted) {
                    this.currentStatus.isMuted = data;
                    statusChanged = true;
                }
                break;
            case 'track-list':
                this.updateTracksFromList(data);
                break;
        }
        if (statusChanged) {
            this.emit('statusChanged', this.currentStatus);
        }
    }
    async updateTracks() {
        try {
            const response = await this.sendCommand({ command: ['get_property', 'track-list'] });
            if (response.data) {
                this.updateTracksFromList(response.data);
            }
        }
        catch (error) {
            console.error('Failed to update tracks:', error);
        }
    }
    updateTracksFromList(trackList) {
        if (!Array.isArray(trackList))
            return;
        const audioTracks = trackList
            .filter(track => track.type === 'audio')
            .map(track => ({
            id: track.id,
            title: track.title,
            language: track.lang,
            codec: track.codec,
        }));
        const subtitleTracks = trackList
            .filter(track => track.type === 'sub')
            .map(track => ({
            id: track.id,
            title: track.title,
            language: track.lang,
            codec: track.codec,
            isDefault: track.default || false,
            isForced: track.forced || false,
        }));
        const tracksChanged = JSON.stringify(this.currentStatus.tracks.audio) !== JSON.stringify(audioTracks) ||
            JSON.stringify(this.currentStatus.tracks.subtitles) !== JSON.stringify(subtitleTracks);
        if (tracksChanged) {
            this.currentStatus.tracks = { audio: audioTracks, subtitles: subtitleTracks };
            this.emit('tracksChanged', this.currentStatus.tracks);
            this.emit('statusChanged', this.currentStatus);
        }
    }
    async sendCommand(command) {
        return new Promise((resolve, reject) => {
            if (!this.socket) {
                reject(new Error('Socket not connected'));
                return;
            }
            const requestId = ++this.requestId;
            const message = { ...command, request_id: requestId };
            this.pendingRequests.set(requestId, (response) => {
                if (response.error && response.error !== 'success') {
                    reject(new Error(`MPV command failed: ${response.error}`));
                }
                else {
                    resolve(response);
                }
            });
            // Set a timeout for the request
            setTimeout(() => {
                if (this.pendingRequests.has(requestId)) {
                    this.pendingRequests.delete(requestId);
                    reject(new Error('MPV command timeout'));
                }
            }, this.config.timeout || 5000);
            try {
                this.socket.write(JSON.stringify(message) + '\n');
            }
            catch (error) {
                this.pendingRequests.delete(requestId);
                reject(error);
            }
        });
    }
}
exports.MpvPlayer = MpvPlayer;
