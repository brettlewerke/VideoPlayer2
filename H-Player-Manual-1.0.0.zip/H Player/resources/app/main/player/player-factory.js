"use strict";
/**
 * Player factory for creating backend instances
 */
Object.defineProperty(exports, "__esModule", { value: true });
exports.PlayerFactory = exports.MockPlayerFactory = exports.MpvPlayerFactory = void 0;
const fs_1 = require("fs");
const path_1 = require("path");
const mpv_player_js_1 = require("./mpv-player.js");
const mock_player_js_1 = require("./mock-player.js");
class MpvPlayerFactory {
    constructor(config) {
        this.config = config;
    }
    createPlayer() {
        return new mpv_player_js_1.MpvPlayer(this.config);
    }
    isAvailable() {
        if (this.config.executablePath) {
            return (0, fs_1.existsSync)(this.config.executablePath);
        }
        // Check common system locations
        const commonPaths = process.platform === 'win32'
            ? ['mpv.exe', 'C:\\Program Files\\mpv\\mpv.exe']
            : process.platform === 'darwin'
                ? ['/usr/local/bin/mpv', '/opt/homebrew/bin/mpv']
                : ['/usr/bin/mpv', '/usr/local/bin/mpv'];
        return commonPaths.some(path => (0, fs_1.existsSync)(path));
    }
    getName() {
        return 'MPV';
    }
}
exports.MpvPlayerFactory = MpvPlayerFactory;
class MockPlayerFactory {
    constructor(config) {
        this.config = config;
    }
    createPlayer() {
        return new mock_player_js_1.MockPlayer(this.config);
    }
    isAvailable() {
        return true; // Mock is always available
    }
    getName() {
        return 'Mock';
    }
}
exports.MockPlayerFactory = MockPlayerFactory;
/**
 * Main player factory that manages all backends
 */
class PlayerFactory {
    constructor() {
        this.factories = new Map();
        this.currentBackend = 'mpv';
        this.registerFactories();
    }
    registerFactories() {
        // Get vendor binary paths
        const vendorPath = (0, path_1.join)(process.cwd(), 'vendor');
        const mpvPath = this.getMpvPath(vendorPath);
        // Register MPV factory
        this.factories.set('mpv', new MpvPlayerFactory({
            name: 'mpv',
            executablePath: mpvPath,
            timeout: 5000,
        }));
        // Register Mock factory
        this.factories.set('mock', new MockPlayerFactory({
            name: 'mock',
        }));
    }
    getMpvPath(vendorPath) {
        const platform = process.platform;
        const arch = process.arch;
        let executable;
        let subdir;
        if (platform === 'win32') {
            executable = 'mpv.exe';
            subdir = arch === 'x64' ? 'win32-x64' : 'win32-ia32';
        }
        else if (platform === 'darwin') {
            executable = 'mpv';
            subdir = arch === 'arm64' ? 'darwin-arm64' : 'darwin-x64';
        }
        else {
            executable = 'mpv';
            subdir = 'linux-x64';
        }
        const fullPath = (0, path_1.join)(vendorPath, 'mpv', subdir, executable);
        if ((0, fs_1.existsSync)(fullPath)) {
            return fullPath;
        }
        // Fallback to system PATH
        return undefined;
    }
    /**
     * Create a player instance using the current backend
     */
    createPlayer() {
        const factory = this.factories.get(this.currentBackend);
        if (!factory) {
            throw new Error(`Unknown player backend: ${this.currentBackend}`);
        }
        if (!factory.isAvailable()) {
            // Try to fall back to mock player
            const mockFactory = this.factories.get('mock');
            if (mockFactory && mockFactory.isAvailable()) {
                console.warn(`Backend ${this.currentBackend} not available, falling back to mock player`);
                return mockFactory.createPlayer();
            }
            throw new Error(`Player backend ${this.currentBackend} is not available`);
        }
        return factory.createPlayer();
    }
    /**
     * Set the current backend
     */
    setBackend(backend) {
        if (!this.factories.has(backend)) {
            throw new Error(`Unknown player backend: ${backend}`);
        }
        this.currentBackend = backend;
    }
    /**
     * Get the current backend name
     */
    getCurrentBackend() {
        return this.currentBackend;
    }
    /**
     * Get all available backends
     */
    getAvailableBackends() {
        return Array.from(this.factories.entries()).map(([name, factory]) => ({
            name,
            isAvailable: factory.isAvailable(),
        }));
    }
    /**
     * Check if a specific backend is available
     */
    isBackendAvailable(backend) {
        const factory = this.factories.get(backend);
        return factory ? factory.isAvailable() : false;
    }
}
exports.PlayerFactory = PlayerFactory;
