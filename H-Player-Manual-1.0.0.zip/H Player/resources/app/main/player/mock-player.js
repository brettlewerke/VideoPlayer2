"use strict";
/**
 * Mock player implementation for testing
 */
Object.defineProperty(exports, "__esModule", { value: true });
exports.MockPlayer = void 0;
const events_1 = require("events");
class MockPlayer extends events_1.EventEmitter {
    constructor(config) {
        super();
        this.config = config;
        this.currentMedia = null;
        this.playbackTimer = null;
        this.currentStatus = {
            state: 'idle',
            position: 0,
            duration: 0,
            volume: 1.0,
            isMuted: false,
            tracks: { audio: [], subtitles: [] },
        };
    }
    async loadMedia(request) {
        try {
            this.currentMedia = request.path;
            this.currentStatus.state = 'loading';
            this.currentStatus.position = request.resumePosition || 0;
            this.currentStatus.duration = 3600; // Mock 1 hour duration
            // Simulate mock tracks
            this.currentStatus.tracks = {
                audio: [
                    { id: 1, title: 'English', language: 'en', codec: 'aac' },
                    { id: 2, title: 'Spanish', language: 'es', codec: 'aac' },
                ],
                subtitles: [
                    { id: 1, title: 'English', language: 'en', codec: 'srt', isDefault: true },
                    { id: 2, title: 'Spanish', language: 'es', codec: 'srt' },
                ],
            };
            this.emit('statusChanged', this.currentStatus);
            // Simulate loading delay
            setTimeout(() => {
                this.currentStatus.state = 'paused';
                this.emit('statusChanged', this.currentStatus);
                this.emit('tracksChanged', this.currentStatus.tracks);
            }, 100);
        }
        catch (error) {
            this.emit('error', new Error(`Failed to load media: ${error}`));
        }
    }
    async play() {
        if (!this.currentMedia) {
            throw new Error('No media loaded');
        }
        this.currentStatus.state = 'playing';
        this.emit('statusChanged', this.currentStatus);
        // Start playback simulation
        this.startPlaybackTimer();
    }
    async pause() {
        this.currentStatus.state = 'paused';
        this.emit('statusChanged', this.currentStatus);
        this.stopPlaybackTimer();
    }
    async stop() {
        this.currentStatus.state = 'stopped';
        this.currentStatus.position = 0;
        this.emit('statusChanged', this.currentStatus);
        this.stopPlaybackTimer();
    }
    async seek(position) {
        this.currentStatus.position = Math.max(0, Math.min(position, this.currentStatus.duration));
        this.emit('statusChanged', this.currentStatus);
    }
    async setVolume(volume) {
        this.currentStatus.volume = Math.max(0, Math.min(1, volume));
        this.emit('statusChanged', this.currentStatus);
    }
    async setMuted(muted) {
        this.currentStatus.isMuted = muted;
        this.emit('statusChanged', this.currentStatus);
    }
    async setAudioTrack(trackId) {
        this.currentStatus.currentAudioTrack = trackId;
        this.emit('statusChanged', this.currentStatus);
    }
    async setSubtitleTrack(trackId) {
        this.currentStatus.currentSubtitleTrack = trackId === -1 ? undefined : trackId;
        this.emit('statusChanged', this.currentStatus);
    }
    getStatus() {
        return { ...this.currentStatus };
    }
    getTracks() {
        return { ...this.currentStatus.tracks };
    }
    async destroy() {
        this.stopPlaybackTimer();
        this.currentMedia = null;
        this.currentStatus.state = 'idle';
        this.removeAllListeners();
    }
    isAvailable() {
        return true; // Mock is always available
    }
    startPlaybackTimer() {
        this.stopPlaybackTimer();
        this.playbackTimer = setInterval(() => {
            if (this.currentStatus.state === 'playing') {
                this.currentStatus.position += 1;
                if (this.currentStatus.position >= this.currentStatus.duration) {
                    this.currentStatus.state = 'idle';
                    this.currentStatus.position = 0;
                    this.stopPlaybackTimer();
                    this.emit('ended');
                }
                this.emit('statusChanged', this.currentStatus);
            }
        }, 1000);
    }
    stopPlaybackTimer() {
        if (this.playbackTimer) {
            clearInterval(this.playbackTimer);
            this.playbackTimer = null;
        }
    }
}
exports.MockPlayer = MockPlayer;
