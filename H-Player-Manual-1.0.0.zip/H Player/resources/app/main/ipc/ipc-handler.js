"use strict";
/**
 * IPC handler for secure communication between main and renderer processes
 */
var __createBinding = (this && this.__createBinding) || (Object.create ? (function(o, m, k, k2) {
    if (k2 === undefined) k2 = k;
    var desc = Object.getOwnPropertyDescriptor(m, k);
    if (!desc || ("get" in desc ? !m.__esModule : desc.writable || desc.configurable)) {
      desc = { enumerable: true, get: function() { return m[k]; } };
    }
    Object.defineProperty(o, k2, desc);
}) : (function(o, m, k, k2) {
    if (k2 === undefined) k2 = k;
    o[k2] = m[k];
}));
var __setModuleDefault = (this && this.__setModuleDefault) || (Object.create ? (function(o, v) {
    Object.defineProperty(o, "default", { enumerable: true, value: v });
}) : function(o, v) {
    o["default"] = v;
});
var __importStar = (this && this.__importStar) || (function () {
    var ownKeys = function(o) {
        ownKeys = Object.getOwnPropertyNames || function (o) {
            var ar = [];
            for (var k in o) if (Object.prototype.hasOwnProperty.call(o, k)) ar[ar.length] = k;
            return ar;
        };
        return ownKeys(o);
    };
    return function (mod) {
        if (mod && mod.__esModule) return mod;
        var result = {};
        if (mod != null) for (var k = ownKeys(mod), i = 0; i < k.length; i++) if (k[i] !== "default") __createBinding(result, mod, k[i]);
        __setModuleDefault(result, mod);
        return result;
    };
})();
Object.defineProperty(exports, "__esModule", { value: true });
exports.IpcHandler = void 0;
const electron_1 = require("electron");
const ipc_js_1 = require("../../shared/ipc.js");
class IpcHandler {
    constructor(database, playerFactory) {
        this.database = database;
        this.playerFactory = playerFactory;
        this.player = null;
    }
    setupHandlers() {
        // Player control handlers
        electron_1.ipcMain.handle(ipc_js_1.IPC_CHANNELS.PLAYER_LOAD, this.handlePlayerLoad.bind(this));
        electron_1.ipcMain.handle(ipc_js_1.IPC_CHANNELS.PLAYER_PLAY, this.handlePlayerPlay.bind(this));
        electron_1.ipcMain.handle(ipc_js_1.IPC_CHANNELS.PLAYER_PAUSE, this.handlePlayerPause.bind(this));
        electron_1.ipcMain.handle(ipc_js_1.IPC_CHANNELS.PLAYER_STOP, this.handlePlayerStop.bind(this));
        electron_1.ipcMain.handle(ipc_js_1.IPC_CHANNELS.PLAYER_SEEK, this.handlePlayerSeek.bind(this));
        electron_1.ipcMain.handle(ipc_js_1.IPC_CHANNELS.PLAYER_SET_VOLUME, this.handlePlayerSetVolume.bind(this));
        electron_1.ipcMain.handle(ipc_js_1.IPC_CHANNELS.PLAYER_SET_MUTED, this.handlePlayerSetMuted.bind(this));
        electron_1.ipcMain.handle(ipc_js_1.IPC_CHANNELS.PLAYER_SET_AUDIO_TRACK, this.handlePlayerSetAudioTrack.bind(this));
        electron_1.ipcMain.handle(ipc_js_1.IPC_CHANNELS.PLAYER_SET_SUBTITLE_TRACK, this.handlePlayerSetSubtitleTrack.bind(this));
        electron_1.ipcMain.handle(ipc_js_1.IPC_CHANNELS.PLAYER_GET_STATUS, this.handlePlayerGetStatus.bind(this));
        electron_1.ipcMain.handle(ipc_js_1.IPC_CHANNELS.PLAYER_GET_TRACKS, this.handlePlayerGetTracks.bind(this));
        // Library handlers
        electron_1.ipcMain.handle(ipc_js_1.IPC_CHANNELS.LIBRARY_GET_MOVIES, this.handleGetMovies.bind(this));
        electron_1.ipcMain.handle(ipc_js_1.IPC_CHANNELS.LIBRARY_GET_SHOWS, this.handleGetShows.bind(this));
        electron_1.ipcMain.handle(ipc_js_1.IPC_CHANNELS.LIBRARY_GET_SEASONS, this.handleGetSeasons.bind(this));
        electron_1.ipcMain.handle(ipc_js_1.IPC_CHANNELS.LIBRARY_GET_EPISODES, this.handleGetEpisodes.bind(this));
        electron_1.ipcMain.handle(ipc_js_1.IPC_CHANNELS.LIBRARY_GET_CONTINUE_WATCHING, this.handleGetContinueWatching.bind(this));
        electron_1.ipcMain.handle(ipc_js_1.IPC_CHANNELS.LIBRARY_GET_RECENTLY_ADDED, this.handleGetRecentlyAdded.bind(this));
        electron_1.ipcMain.handle(ipc_js_1.IPC_CHANNELS.LIBRARY_SEARCH, this.handleLibrarySearch.bind(this));
        electron_1.ipcMain.handle(ipc_js_1.IPC_CHANNELS.LIBRARY_GET_PROGRESS, this.handleGetProgress.bind(this));
        electron_1.ipcMain.handle(ipc_js_1.IPC_CHANNELS.LIBRARY_SET_PROGRESS, this.handleSetProgress.bind(this));
        // Drive handlers
        electron_1.ipcMain.handle(ipc_js_1.IPC_CHANNELS.DRIVES_GET_ALL, this.handleGetDrives.bind(this));
        // Settings handlers
        electron_1.ipcMain.handle(ipc_js_1.IPC_CHANNELS.SETTINGS_GET, this.handleGetSettings.bind(this));
        electron_1.ipcMain.handle(ipc_js_1.IPC_CHANNELS.SETTINGS_SET, this.handleSetSettings.bind(this));
        // App handlers
        electron_1.ipcMain.handle(ipc_js_1.IPC_CHANNELS.APP_GET_VERSION, this.handleGetVersion.bind(this));
        electron_1.ipcMain.handle(ipc_js_1.IPC_CHANNELS.APP_QUIT, this.handleAppQuit.bind(this));
        electron_1.ipcMain.handle(ipc_js_1.IPC_CHANNELS.APP_MINIMIZE, this.handleAppMinimize.bind(this));
        electron_1.ipcMain.handle(ipc_js_1.IPC_CHANNELS.APP_TOGGLE_FULLSCREEN, this.handleToggleFullscreen.bind(this));
        console.log('IPC handlers set up successfully');
    }
    cleanup() {
        if (this.player) {
            this.player.destroy();
            this.player = null;
        }
        // Remove all listeners (Electron does this automatically on app quit)
        electron_1.ipcMain.removeAllListeners();
    }
    sendToRenderer(channel, data) {
        const windows = electron_1.BrowserWindow.getAllWindows();
        windows.forEach(window => {
            if (!window.isDestroyed()) {
                window.webContents.send(channel, data);
            }
        });
    }
    // Player handlers
    async handlePlayerLoad(event, request) {
        try {
            if (!(0, ipc_js_1.validatePath)(request.path)) {
                throw new Error('Invalid file path');
            }
            if (!this.player) {
                this.player = this.playerFactory.createPlayer();
                this.setupPlayerEvents();
            }
            await this.player.loadMedia(request);
            return (0, ipc_js_1.createIpcResponse)(event.frameId.toString(), undefined);
        }
        catch (error) {
            return (0, ipc_js_1.createIpcResponse)(event.frameId.toString(), undefined, error instanceof Error ? error.message : 'Unknown error');
        }
    }
    async handlePlayerPlay(event) {
        try {
            if (!this.player) {
                throw new Error('No player available');
            }
            await this.player.play();
            return (0, ipc_js_1.createIpcResponse)(event.frameId.toString(), undefined);
        }
        catch (error) {
            return (0, ipc_js_1.createIpcResponse)(event.frameId.toString(), undefined, error instanceof Error ? error.message : 'Unknown error');
        }
    }
    async handlePlayerPause(event) {
        try {
            if (!this.player) {
                throw new Error('No player available');
            }
            await this.player.pause();
            return (0, ipc_js_1.createIpcResponse)(event.frameId.toString(), undefined);
        }
        catch (error) {
            return (0, ipc_js_1.createIpcResponse)(event.frameId.toString(), undefined, error instanceof Error ? error.message : 'Unknown error');
        }
    }
    async handlePlayerStop(event) {
        try {
            if (!this.player) {
                throw new Error('No player available');
            }
            await this.player.stop();
            return (0, ipc_js_1.createIpcResponse)(event.frameId.toString(), undefined);
        }
        catch (error) {
            return (0, ipc_js_1.createIpcResponse)(event.frameId.toString(), undefined, error instanceof Error ? error.message : 'Unknown error');
        }
    }
    async handlePlayerSeek(event, position) {
        try {
            if (!(0, ipc_js_1.validatePosition)(position)) {
                throw new Error('Invalid seek position');
            }
            if (!this.player) {
                throw new Error('No player available');
            }
            await this.player.seek(position);
            return (0, ipc_js_1.createIpcResponse)(event.frameId.toString(), undefined);
        }
        catch (error) {
            return (0, ipc_js_1.createIpcResponse)(event.frameId.toString(), undefined, error instanceof Error ? error.message : 'Unknown error');
        }
    }
    async handlePlayerSetVolume(event, volume) {
        try {
            if (!(0, ipc_js_1.validateVolume)(volume)) {
                throw new Error('Invalid volume level');
            }
            if (!this.player) {
                throw new Error('No player available');
            }
            await this.player.setVolume(volume);
            return (0, ipc_js_1.createIpcResponse)(event.frameId.toString(), undefined);
        }
        catch (error) {
            return (0, ipc_js_1.createIpcResponse)(event.frameId.toString(), undefined, error instanceof Error ? error.message : 'Unknown error');
        }
    }
    async handlePlayerSetMuted(event, muted) {
        try {
            if (!this.player) {
                throw new Error('No player available');
            }
            await this.player.setMuted(muted);
            return (0, ipc_js_1.createIpcResponse)(event.frameId.toString(), undefined);
        }
        catch (error) {
            return (0, ipc_js_1.createIpcResponse)(event.frameId.toString(), undefined, error instanceof Error ? error.message : 'Unknown error');
        }
    }
    async handlePlayerSetAudioTrack(event, trackId) {
        try {
            if (!(0, ipc_js_1.validateTrackId)(trackId)) {
                throw new Error('Invalid track ID');
            }
            if (!this.player) {
                throw new Error('No player available');
            }
            await this.player.setAudioTrack(trackId);
            return (0, ipc_js_1.createIpcResponse)(event.frameId.toString(), undefined);
        }
        catch (error) {
            return (0, ipc_js_1.createIpcResponse)(event.frameId.toString(), undefined, error instanceof Error ? error.message : 'Unknown error');
        }
    }
    async handlePlayerSetSubtitleTrack(event, trackId) {
        try {
            if (!(0, ipc_js_1.validateTrackId)(trackId)) {
                throw new Error('Invalid track ID');
            }
            if (!this.player) {
                throw new Error('No player available');
            }
            await this.player.setSubtitleTrack(trackId);
            return (0, ipc_js_1.createIpcResponse)(event.frameId.toString(), undefined);
        }
        catch (error) {
            return (0, ipc_js_1.createIpcResponse)(event.frameId.toString(), undefined, error instanceof Error ? error.message : 'Unknown error');
        }
    }
    async handlePlayerGetStatus(event) {
        try {
            if (!this.player) {
                throw new Error('No player available');
            }
            const status = this.player.getStatus();
            return (0, ipc_js_1.createIpcResponse)(event.frameId.toString(), status);
        }
        catch (error) {
            return (0, ipc_js_1.createIpcResponse)(event.frameId.toString(), undefined, error instanceof Error ? error.message : 'Unknown error');
        }
    }
    async handlePlayerGetTracks(event) {
        try {
            if (!this.player) {
                throw new Error('No player available');
            }
            const tracks = this.player.getTracks();
            return (0, ipc_js_1.createIpcResponse)(event.frameId.toString(), tracks);
        }
        catch (error) {
            return (0, ipc_js_1.createIpcResponse)(event.frameId.toString(), undefined, error instanceof Error ? error.message : 'Unknown error');
        }
    }
    setupPlayerEvents() {
        if (!this.player)
            return;
        this.player.on('statusChanged', (status) => {
            this.sendToRenderer(ipc_js_1.IPC_CHANNELS.PLAYER_STATUS_CHANGED, status);
        });
        this.player.on('tracksChanged', (tracks) => {
            this.sendToRenderer(ipc_js_1.IPC_CHANNELS.PLAYER_TRACKS_CHANGED, tracks);
        });
        this.player.on('ended', () => {
            this.sendToRenderer(ipc_js_1.IPC_CHANNELS.PLAYER_ENDED);
        });
        this.player.on('error', (error) => {
            this.sendToRenderer(ipc_js_1.IPC_CHANNELS.PLAYER_ERROR, error.message);
        });
    }
    // Library handlers
    async handleGetMovies(event, driveId) {
        try {
            const movies = await this.database.getMovies(driveId);
            return (0, ipc_js_1.createIpcResponse)(event.frameId.toString(), movies);
        }
        catch (error) {
            return (0, ipc_js_1.createIpcResponse)(event.frameId.toString(), undefined, error instanceof Error ? error.message : 'Unknown error');
        }
    }
    async handleGetShows(event, driveId) {
        try {
            const shows = await this.database.getShows(driveId);
            return (0, ipc_js_1.createIpcResponse)(event.frameId.toString(), shows);
        }
        catch (error) {
            return (0, ipc_js_1.createIpcResponse)(event.frameId.toString(), undefined, error instanceof Error ? error.message : 'Unknown error');
        }
    }
    async handleGetSeasons(event, showId) {
        try {
            const seasons = await this.database.getSeasons(showId);
            return (0, ipc_js_1.createIpcResponse)(event.frameId.toString(), seasons);
        }
        catch (error) {
            return (0, ipc_js_1.createIpcResponse)(event.frameId.toString(), undefined, error instanceof Error ? error.message : 'Unknown error');
        }
    }
    async handleGetEpisodes(event, seasonId) {
        try {
            const episodes = await this.database.getEpisodes(seasonId);
            return (0, ipc_js_1.createIpcResponse)(event.frameId.toString(), episodes);
        }
        catch (error) {
            return (0, ipc_js_1.createIpcResponse)(event.frameId.toString(), undefined, error instanceof Error ? error.message : 'Unknown error');
        }
    }
    async handleGetContinueWatching(event) {
        try {
            const progress = await this.database.getContinueWatching();
            return (0, ipc_js_1.createIpcResponse)(event.frameId.toString(), progress);
        }
        catch (error) {
            return (0, ipc_js_1.createIpcResponse)(event.frameId.toString(), undefined, error instanceof Error ? error.message : 'Unknown error');
        }
    }
    async handleGetRecentlyAdded(event) {
        try {
            const movies = await this.database.getRecentMovies(5);
            const episodes = await this.database.getRecentEpisodes(5);
            return (0, ipc_js_1.createIpcResponse)(event.frameId.toString(), { movies, episodes });
        }
        catch (error) {
            return (0, ipc_js_1.createIpcResponse)(event.frameId.toString(), undefined, error instanceof Error ? error.message : 'Unknown error');
        }
    }
    async handleLibrarySearch(event, query) {
        try {
            const movies = await this.database.searchMovies(query);
            const shows = await this.database.searchShows(query);
            return (0, ipc_js_1.createIpcResponse)(event.frameId.toString(), { movies, shows });
        }
        catch (error) {
            return (0, ipc_js_1.createIpcResponse)(event.frameId.toString(), undefined, error instanceof Error ? error.message : 'Unknown error');
        }
    }
    async handleGetProgress(event, mediaId) {
        try {
            const progress = await this.database.getProgress(mediaId);
            return (0, ipc_js_1.createIpcResponse)(event.frameId.toString(), progress);
        }
        catch (error) {
            return (0, ipc_js_1.createIpcResponse)(event.frameId.toString(), undefined, error instanceof Error ? error.message : 'Unknown error');
        }
    }
    async handleSetProgress(event, progress) {
        try {
            await this.database.setProgress(progress);
            return (0, ipc_js_1.createIpcResponse)(event.frameId.toString(), undefined);
        }
        catch (error) {
            return (0, ipc_js_1.createIpcResponse)(event.frameId.toString(), undefined, error instanceof Error ? error.message : 'Unknown error');
        }
    }
    // Drive handlers
    async handleGetDrives(event) {
        try {
            const drives = await this.database.getDrives();
            return (0, ipc_js_1.createIpcResponse)(event.frameId.toString(), drives);
        }
        catch (error) {
            return (0, ipc_js_1.createIpcResponse)(event.frameId.toString(), undefined, error instanceof Error ? error.message : 'Unknown error');
        }
    }
    // Settings handlers
    async handleGetSettings(event) {
        try {
            const settings = await this.database.getAllSettings();
            return (0, ipc_js_1.createIpcResponse)(event.frameId.toString(), settings);
        }
        catch (error) {
            return (0, ipc_js_1.createIpcResponse)(event.frameId.toString(), undefined, error instanceof Error ? error.message : 'Unknown error');
        }
    }
    async handleSetSettings(event, key, value) {
        try {
            await this.database.setSetting(key, value);
            return (0, ipc_js_1.createIpcResponse)(event.frameId.toString(), undefined);
        }
        catch (error) {
            return (0, ipc_js_1.createIpcResponse)(event.frameId.toString(), undefined, error instanceof Error ? error.message : 'Unknown error');
        }
    }
    // App handlers
    async handleGetVersion(event) {
        try {
            const { app } = await Promise.resolve().then(() => __importStar(require('electron')));
            const version = app.getVersion();
            return (0, ipc_js_1.createIpcResponse)(event.frameId.toString(), version);
        }
        catch (error) {
            return (0, ipc_js_1.createIpcResponse)(event.frameId.toString(), undefined, error instanceof Error ? error.message : 'Unknown error');
        }
    }
    async handleAppQuit(event) {
        try {
            const { app } = await Promise.resolve().then(() => __importStar(require('electron')));
            app.quit();
            return (0, ipc_js_1.createIpcResponse)(event.frameId.toString(), undefined);
        }
        catch (error) {
            return (0, ipc_js_1.createIpcResponse)(event.frameId.toString(), undefined, error instanceof Error ? error.message : 'Unknown error');
        }
    }
    async handleAppMinimize(event) {
        try {
            const window = electron_1.BrowserWindow.fromWebContents(event.sender);
            if (window) {
                window.minimize();
            }
            return (0, ipc_js_1.createIpcResponse)(event.frameId.toString(), undefined);
        }
        catch (error) {
            return (0, ipc_js_1.createIpcResponse)(event.frameId.toString(), undefined, error instanceof Error ? error.message : 'Unknown error');
        }
    }
    async handleToggleFullscreen(event) {
        try {
            const window = electron_1.BrowserWindow.fromWebContents(event.sender);
            if (window) {
                window.setFullScreen(!window.isFullScreen());
            }
            return (0, ipc_js_1.createIpcResponse)(event.frameId.toString(), undefined);
        }
        catch (error) {
            return (0, ipc_js_1.createIpcResponse)(event.frameId.toString(), undefined, error instanceof Error ? error.message : 'Unknown error');
        }
    }
}
exports.IpcHandler = IpcHandler;
